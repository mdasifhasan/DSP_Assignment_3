# DSP_Assignment_3
ZooKeeper Register/Lookup in Publish-Subscribe using ZMQ and Mininet


Test Instruction:
1. Zookeeper must be run on 10.0.0.1 ip address

2. To run EventService:
python ZEventService.py self_ip

3. To run Publisher:
python Publisher.py any_event_service_ip

4. To run Subscriber:
python Subscriber.py any_event_service_ip

